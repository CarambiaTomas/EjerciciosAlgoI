package ejercicio_torneo.controller;
import java.util.List;
import java.util.ArrayList;
import ejercicio_torneo.entity.Equipo;
import ejercicio_torneo.entity.Partido;
import java.time.LocalDate;

public class Torneo {

    //Atributos
    List<Equipo> equipos = new ArrayList<>();
    List<Partido> partidos = new ArrayList<>();

    //Constructor
    public Torneo(){

    }

    //Comportamiento

    public void cargarEquipo(String nombre, int fans){
        //Verifico que el equipo no esté cargado
        if(encontrarEquipo(nombre)!=-1){
            throw new RuntimeException("El equipo"+nombre+"ya estaba cargado previamente en el torneo");
        }
        Equipo e = new Equipo(nombre,fans);
        equipos.add(e);
        System.out.println("Equipo cargado exitosamente.");
    }

    public void cargarPartido(String local, String visitante, LocalDate fecha, int golesL, int golesV){
        //Manejar, si me queda tiempo, la posibilidad de que un partido no se cargue 2 veces
        int indice_l = encontrarEquipo(local);
        int indice_v = encontrarEquipo(visitante);
        //Verifico que cada equipo esté cargado en el torneo, si uno no lo esta arrojo una excepción
        if(indice_l==-1){
            throw new RuntimeException("El equipo"+local+"no está cargado en el torneo");
        }
        if(indice_v==-1){
            throw new RuntimeException("El equipo"+visitante+"no está cargado en el torneo");
        }
        //Una vez verificada la existencia de los dos equipos instancio el partido
        Partido p = new Partido(equipos.get(indice_l), equipos.get(indice_v), fecha, golesL, golesV);

        //Guardo el partido en partidos
        partidos.add(p);
        System.out.println("Partido cargado");
    }

    public void mostrarPartidosFecha(LocalDate f){
        System.out.println("Se muestran los partidos de la fecha "+ f);
        for (Partido p :partidos){
            if(p.getFecha().equals(f)){
                System.out.println(p);
            }
        }
    }

    public void mostrarTabla(){
        //Ordenar lista de equipos, primero por puntos, despues por diferencia de gol, despues por goles a favor
        ordenarEquipos();
        ordenarEquiposDG();
        ordenarEquiposGF();
        System.out.println("Equipo | Ju | Pu | Ga | Em | Pe | GF | GC | DG");
        for(int i = equipos.size()-1; i>=0; i--){
            System.out.println(equipos.get(i));
        }
    }

    private int encontrarEquipo(String n){
        for (int i=0;i<equipos.size();i++){
            if(equipos.get(i).getNombre().equals(n)){
                return i;}
        }
        return -1;
    }

    private void ordenarEquipos() {
        
        int n = equipos.size();
        boolean huboCambio;
        do {
            huboCambio = false;
            for (int i = 1; i < n; i++) {
                if (equipos.get(i - 1).getPuntos() > equipos.get(i).getPuntos()) {
                    // Intercambia arreglo[i-1] y arreglo[i]
                    Equipo temp = equipos.get(i - 1);
                    equipos.set(i - 1, equipos.get(i));
                    equipos.set(i, temp);
                    huboCambio = true;
                }
            }
            n--;
        } while (huboCambio);
    }
    private void ordenarEquiposDG(){
         
        int n = equipos.size();
        boolean huboCambio;
        do {
            huboCambio = false;
            for (int i = 1; i < n; i++) {
                if (equipos.get(i - 1).getPuntos() == equipos.get(i).getPuntos() && equipos.get(i - 1).getDG() > equipos.get(i).getDG()) {
                    // Intercambia arreglo[i-1] y arreglo[i]
                    Equipo temp = equipos.get(i - 1);
                    equipos.set(i - 1, equipos.get(i));
                    equipos.set(i, temp);
                    huboCambio = true;
                }
            }
            n--;
        } while (huboCambio);       
    }
    private void ordenarEquiposGF(){
         
        int n = equipos.size();
        boolean huboCambio;
        do {
            huboCambio = false;
            for (int i = 1; i < n; i++) {
                if (equipos.get(i - 1).getPuntos() == equipos.get(i).getPuntos() && equipos.get(i - 1).getDG() == equipos.get(i).getDG() && equipos.get(i - 1).getGF() > equipos.get(i).getGF()) {
                    // Intercambia arreglo[i-1] y arreglo[i]
                    Equipo temp = equipos.get(i - 1);
                    equipos.set(i - 1, equipos.get(i));
                    equipos.set(i, temp);
                    huboCambio = true;
                }
            }
            n--;
        } while (huboCambio);       
    }
}
