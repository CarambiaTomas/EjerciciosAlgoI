package ejercicio_torneo.entity;

public class Equipo {

    //Atributos
    private String nombre;
    private int fans;
    private int puntos = 0;
    private int perdidos = 0;
    private int ganados = 0;
    private int empatados = 0;
    private int jugados = 0;
    private int gf =0;
    private int gc = 0;
    private int dg = 0;

    //Constructor
    public Equipo(String nombre, int fans){
        this.nombre = nombre;
        this.fans = fans;
    }

    //Getters
    public String getNombre(){
        return nombre;
    }
    public int getFans(){
        return fans;
    }
    public int getPuntos(){
        return puntos;
    }
    public int getDG(){
        return dg;
    }
    public int getGF(){
        return gf;
    }
    

    //Setters
    public void setFans(int f){
        this.fans = f;
    }
    //Comportamiento
    public void agregarVictoria(int gf, int gc){
        jugados++;
        ganados++;
        this.gf += gf;
        this.gc += gc; 
        puntos += 3;
        calcularDG();
        
    }
    public void agregarDerrota(int gf, int gc){
        jugados++;
        perdidos++;
        this.gf += gf;
        this.gc += gc; 
        calcularDG();
    }
    public void agregarEmpate(int gf, int gc){
        jugados++;
        empatados++;
        this.gf += gf;
        this.gc += gc; 
        puntos += 1;
        calcularDG();
    }

    private void calcularDG(){
        this.dg = gf-gc;
    }

    @Override
    public String toString(){
        return nombre + " | "+
               jugados+ " | "+
               puntos+ " | "+
               ganados+ " | "+
               empatados+ " | "+
               perdidos+ " | "+
               gf+ " | "+
               gc+ " | "+
               dg;
    }
}
