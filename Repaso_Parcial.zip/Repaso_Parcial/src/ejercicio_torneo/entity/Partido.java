package ejercicio_torneo.entity;

import java.time.LocalDate;

public class Partido {
    private Equipo local;
    private Equipo visitante;
    private LocalDate fecha;
    private int golesL;
    private int golesV;

    public Partido(Equipo l, Equipo v, LocalDate f, int golesL, int golesV){
        this.local = l;
        this.visitante = v;
        this.fecha = f;
        this.golesL = golesL;
        this.golesV = golesV;
        cargarResultados();
    }

    private void cargarResultados(){
        if(golesL>golesV){
            local.agregarVictoria(golesL, golesV);
            visitante.agregarDerrota(golesV, golesL);
        }
        else if(golesL<golesV){
            local.agregarDerrota(golesL, golesV);
            visitante.agregarVictoria(golesV, golesL);
        }
        else{
            local.agregarEmpate(golesL, golesV);
            visitante.agregarEmpate(golesV, golesL);
        }
    }

    public String toString(){
        return "Fecha: "+ fecha + ", " + local.getNombre() + " (" + golesL+ ") - "+visitante.getNombre()+" ("+ golesV + ")";
    }

    //Getter
    public LocalDate getFecha(){
        return fecha;
    }


}
