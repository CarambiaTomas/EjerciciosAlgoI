package ejercicio_ong;

import java.time.LocalDate;

public class Donacion {
    //Atributos
    private LocalDate fecha;
    private Donante donante;
    private float monto;
    private int id;
    private Estado estado;
    private static int ult_id;

    //Constructor
    public Donacion(Donante donante, LocalDate fecha, float monto){
        this.donante = donante;
        this.fecha = fecha;
        this.monto = monto;
        this.estado = Estado.PENDIENTE;
        generarId();
    }

    //Comportamiento
    private void generarId(){
        this.id = ult_id+1;
        ult_id++;
    }

    public String toString(){
        return  "Donacion: "+ id +"\n"+
                "- Donante: " + donante + "\n"+
                "- Fecha: " + fecha + "\n"+
                "- Estado: " + estado + "\n"+
                "- Monto: "+ monto;
    }

    //Getters
    public LocalDate getFecha(){
        return fecha;
    }
    public Donante getDonante(){
        return donante;
    }
    public float getMonto(){
        return monto;
    }
    public int getId(){
        return id;
    }
    public Estado getEstado(){
        return estado;
    }

    //Setters
    public void setCobrada(){
        if(estado==Estado.PENDIENTE){
            this.estado = Estado.COBRADA;
        }else{System.out.println("La donación ya había sido rechazada o cobrada");}
        
    }
    public void setRechazada(){
        if(estado==Estado.PENDIENTE){
        this.estado = Estado.RECHAZADA;
        }else{System.out.println("La donación ya había sido rechazada o cobrada");}
    }
}
