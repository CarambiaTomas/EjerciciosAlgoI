package ejercicio_ong;

public class Donante {
    //Atributos
    private String nombre;
    private String apellido;
    private int id;
    private static int ult_id=0;
    
    //Constructor
    public Donante(String nombre, String apellido){
        this.nombre = nombre;
        this.apellido = apellido;
        generarId();
    }

    //Comportamiento

    private void generarId(){
        this.id = ult_id+1;
        ult_id++;
    }

    //getters
    public String getNombre(){
        return nombre;
    }
    public String getApellido(){
        return apellido;
    }
    public int getId(){
        return id;
    }
    @Override
    public String toString(){
        return "("+this.id+") " + this.apellido + ", "+this.nombre;
    }
}
