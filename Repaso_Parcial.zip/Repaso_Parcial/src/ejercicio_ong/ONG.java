package ejercicio_ong;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;

public class ONG {
    //Atributos
    private String nombre;
    private List<Donante> donantes;
    private List<Donacion> donaciones;

    //Constructor
    public ONG(String nombre){
        this.nombre = nombre;
        this.donantes = new ArrayList<>();
        this.donaciones = new ArrayList<>();
    }

    //Comportamiento
    public Donante registrarDonante(String nombre, String apellido){
        //Verificar si el donante está en la organizacion
        int idCheck = verificarIdentidad(nombre, apellido);
        if(idCheck == -1){
            Donante donante = new Donante(nombre, apellido);
            donantes.add(donante);
            System.out.println("Donante registrado exitosamente");
            return donante;
        }else{
            System.out.print("Donante previamente registrado");
            return donantes.get(idCheck);  
        }
        
    }

    private int verificarIdentidad(String nombre, String apellido){
        if(donantes.isEmpty()){
            return -1;
        }
        int i=0;
        for(Donante donante:donantes){
            if(donante.getNombre().equals(nombre)&&donante.getApellido().equals(apellido)){
                return i;
            }
            i++;
        }
        return -1;
    }

    public Donacion cargarDonacion(Donante donante, LocalDate fecha, float monto){
        int idCheck = verificarIdentidad(donante.getNombre(), donante.getApellido());
        if(idCheck==-1){
            donantes.add(donante);
        }
        Donacion donacion = new Donacion(donante, fecha, monto);
        donaciones.add(donacion);
        System.out.println("Donación cargada exitosamente");
        ordenarDonaciones();
        return donacion;
    }
    public void mostrarDonantes(){
        if(donantes.isEmpty()){
            System.out.println("No se han registrado donantes aún");
            return;
        }
        System.out.println("Listado de donantes de "+ this.nombre);
        for(Donante dnt:donantes){
            System.out.println(dnt);
        }
    }

    public void mostrarDonaciones(){
        
        for(Donacion donacion:donaciones){
            System.out.println(donacion);
        }
    }

    private void ordenarDonaciones() {
        int n = donaciones.size();
        boolean huboCambio;
        do {
            huboCambio = false;
            for (int i = 1; i < n; i++) {
                if (donaciones.get(i - 1).getFecha().isAfter(donaciones.get(i).getFecha())) {
                    // Intercambia arreglo[i-1] y arreglo[i]
                    Donacion temp = donaciones.get(i - 1);
                    donaciones.set(i - 1, donaciones.get(i));
                    donaciones.set(i,temp);
                    huboCambio = true;
                }
            }
            n--;
        } while (huboCambio);
    }

    public void mostrarResultadoFecha(LocalDate f){
        int pendientes = 0;
        int cobradas = 0;
        int rechazadas = 0;
        float total = 0;
        float maximo = 0;
        float minimo = 0;
        int i =0;
        float medio =0;
        if(!donaciones.isEmpty()){
            maximo = donaciones.get(0).getMonto();
            minimo = donaciones.get(0).getMonto();
            for (Donacion donacion:donaciones){
                if(donacion.getFecha().isAfter(f)){break;}
                switch (donacion.getEstado()){
                    case PENDIENTE:
                        pendientes++;
                        break;
                    case RECHAZADA:
                        rechazadas++;
                        break;
                    case COBRADA:
                        cobradas++;
                        break;
                }
                float m = donacion.getMonto();
                total +=m;
                if (m>maximo){maximo=m;}
                else if(m<minimo){minimo=m;}
                i++;
            }
            try{
                medio = total/i;
            }catch(ArithmeticException e){
                System.out.println("Error: División por cero. " + e.getMessage());
                medio = 0;
            }
        }

        System.out.println("Estado de resultado de "+this.nombre+" al "+f+": \n"+
            "- Cobradas: "+cobradas+"\n"+
            "- Rechazadas: "+rechazadas+"\n"+
            "- Pendientes: "+pendientes+"\n"+
            "- Monto total: "+ total+"\n"+
            "- Monto máximo: "+maximo+"\n"+
            "- Monto mínimo: "+minimo+"\n"+
            "- Monto medio: "+medio
        );
        
    }
}
