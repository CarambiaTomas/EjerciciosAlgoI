package ejercicio_ong;

public enum Estado {
    PENDIENTE,
    RECHAZADA,
    COBRADA
}
