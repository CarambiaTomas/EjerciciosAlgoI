package ejercicio_hospital.entity;

public enum ZonaCuerpo {
    ABDOMEN,
    CADERA,
    COLUMNA,
    CRANEO,
    TORAX,
    TIBIA
}
