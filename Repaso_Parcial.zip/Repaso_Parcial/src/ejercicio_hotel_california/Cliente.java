package ejercicio_hotel_california;

public class Cliente {
    private String nombre;

    //Constructor
    public Cliente(String nombre){
        this.nombre = nombre;
    }

    //getters
    public String getNombre(){
        return nombre;
    }
}
