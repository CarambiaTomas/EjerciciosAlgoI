package ejercicio_hotel_california;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;

public class Habitacion {

    //atributos

    private int capacidad;
    private int num_habitacion;
    private static int ult_numero = 0;
    private List<LocalDate> fechas;

    //constructor
    public Habitacion(int capacidad){
        this.capacidad = capacidad;
        generarNumero();
        fechas = new ArrayList<>();
        System.out.println("Habitación creada exitosamente");
    }

    private void generarNumero(){
        this.num_habitacion = ult_numero+1;
        ult_numero++;
    }

    //getters
    public int getCapacidad(){
       return capacidad; 
    }

    public int getNumero(){
        return num_habitacion;
    }

    //setters


    //Comportamiento
    protected void reservarFechas(LocalDate checkin, LocalDate checkout){
        List<LocalDate> rango = generarRangoDeFechas(checkin, checkout);
        fechas.addAll(rango); 
    }

    private List<LocalDate> generarRangoDeFechas(LocalDate f_inicio, LocalDate f_cierre){
        List<LocalDate> rango = new ArrayList<>();
        LocalDate f= f_inicio;
        while(!f.isEqual(f_cierre)){
            rango.add(f);
            f = f.plusDays(1);
        }
        return rango;
    }
    
    public void quitarFechas(LocalDate checkin, LocalDate checkout){
        List<LocalDate> rango = generarRangoDeFechas(checkin, checkout);
        for (LocalDate f:rango){
            int i = 0;
            for(LocalDate fecha:fechas){
                if(f.isEqual(fecha)){
                    fechas.remove(i);
                    break;
                }
                i++;
            }
        }
    }
    //Agregar tambien un metodo para sacar las fechas una vez cumplida la reserva

    public boolean isDisponible(LocalDate checkin, LocalDate checkout){
        if(this.fechas ==null || this.fechas.isEmpty()){
            return true;
        }
        List<LocalDate> rango = generarRangoDeFechas(checkin, checkout);
        for (LocalDate f:rango){
            if (fechas.contains(f)){return false;}
        }
        return true;
    }

    public List<LocalDate> getFechas(){
        return fechas;
    }

    //ToString
    public String toString(){
        return "Habitacion Base: "+ this.num_habitacion +" capacidad = " +this.capacidad + " pax.";
    }
}
