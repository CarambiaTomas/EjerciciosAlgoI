package ejercicio_hotel_california;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class Hotel {
    private String nombre;
    private String direccion;
    private static float precio = 0;
    private List<Habitacion> habitaciones;
    private List<Reserva> reservas;
    

    //Constructores

    public Hotel(String nombre, String direccion){
        this.nombre = nombre;
        this.direccion = direccion;
        habitaciones = new ArrayList<>();
        reservas = new ArrayList<>();
    }
    public Hotel(String nombre, String direccion, float precio){
        this.nombre = nombre;
        this.direccion = direccion;
        this.precio = precio;
        habitaciones = new ArrayList<>();
        reservas = new ArrayList<>();
    }

    //Setter
    public void definirPrecioNoche(float precio){
        this.precio = precio;
    }

    //getters
    public String getNombre(){
        return nombre;
    }

    public String getDireccion(){
        return direccion;
    }
    public static float getPrecio(){
        return precio;
    }
    public Habitacion getHabitacion(int numero){
        //Agregar excepcion por si la lista de habitaciones está vacía
        if(habitaciones == null || habitaciones.isEmpty()){
            return null;
        }
        for (Habitacion habitacion : habitaciones){
            if(habitacion.getNumero()==numero){
                return habitacion;
            }
        }
        return null;
    }

    public void verReservas(){
        System.out.println("* Reservas del hotel "+this.nombre);
        int i = 1;
        for (Reserva reserva: reservas){
            System.out.println("** Reserva "+i);
            System.out.println(reserva);
            i++;
        }
    }

    //Comportamiento
    public void agregarHabitacion(int capacidad){
        //instancia un objeto habitacion y lo agrega a la lista.
        habitaciones.add(new Habitacion(capacidad));
    }

    public void consultarDisponibilidad(LocalDate checkin, LocalDate checkout){
        System.out.println("habitaciones disponibles del "+checkin+" al "+checkout+": ");
        for(Habitacion habitacion : habitaciones){
            if(habitacion.isDisponible(checkin, checkout)){
                System.out.println(habitacion);
            }
        }
    }

    public void reservarHabitacion(Cliente cliente, LocalDate checkin, LocalDate checkout, int huespedes){
        if(habitaciones==null || this.habitaciones.isEmpty()){
            System.out.println("No hay habitaciones disponibles en este momento");
            return;
        }
        //Revisar más adelante para encontrar una mejor forma de encontrar habitaciones (si queda tiempo)
        for (Habitacion habitacion : habitaciones){
            if(habitacion.isDisponible(checkin, checkout) && habitacion.getCapacidad()>= huespedes){
                habitacion.reservarFechas(checkin,checkout);
                Reserva nueva_reserva = new Reserva(cliente,checkin,checkout,huespedes,habitacion);
                reservas.add(nueva_reserva);
                System.out.println("Reserva creada exitosamente. ");
                return;   
            }else{continue;}
        }
        System.out.println("No se ha podido crear la reserva");
        return;
    }

    public void cancelarReserva(int id){
        int i =0;
        for (Reserva reserva:reservas){
            if(reserva.getId() == id){
                LocalDate ci = reserva.getCheckIn();
                LocalDate co = reserva.getCheckOut();
                Habitacion habitacion = reserva.getHabitacion();
                habitacion.quitarFechas(ci, co);
                reservas.remove(i);
                return;
            }
            i++;
        }
        System.out.println("El id ingresado no corresponde a ninguna reserva");
        return;
    }
}
