package ejercicio_hotel_california;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Reserva {
    private LocalDate checkin;
    private LocalDate checkout;
    private int huespedes;
    private Cliente cliente; 
    private Habitacion habitacion;
    private int noches;
    private float precio;
    private int id;
    private static int ult_numero = 0;

    //Constructor 

    public Reserva(Cliente cliente, LocalDate checkin, LocalDate checkout, int huespedes, Habitacion habitacion){
        this.cliente = cliente;
        this.checkin = checkin;
        this.checkout = checkout;
        this.huespedes = huespedes;
        this.habitacion = habitacion;
        this.noches = calcularNoches(checkin, checkout);
        this.precio = Hotel.getPrecio()*noches;
        generarId();
    }

    //Comportamiento
    private int calcularNoches(LocalDate checkin, LocalDate checkout){
        List<LocalDate> rango = new ArrayList<>();
        LocalDate f= checkin;
        while(!f.isEqual(checkout)){
            rango.add(f);
            f = f.plusDays(1);
        }
        return rango.size();
    }

    private void generarId(){
        this.id = ult_numero+1;
        ult_numero++;
    }

    //Getters
    public LocalDate getCheckIn(){
        return checkin;
    }
    public LocalDate getCheckOut(){
        return checkout;
    }
    public int getHuespedes(){
        return huespedes;
    }
    public Cliente getCliente(){
        return cliente;
    }
    public int getId(){
        return id;
    }
    public Habitacion getHabitacion(){
        return habitacion;
    }

    // ToString
    @Override
    public String toString(){
        return "-"+habitacion+"\n"+
                "- Cliente: "+cliente.getNombre()+"\n"+
                "- Check-in: "+checkin +"\n"+
                "- Check-out: "+checkout +"\n"+
                "- Cantidad de noches: "+noches+"\n"+
                "- Monto: $"+ precio;
    }

}
